﻿using Microsoft.AspNetCore.Mvc;

namespace project2_01.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
    }
}

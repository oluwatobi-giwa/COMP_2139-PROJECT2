﻿using comp2139_project_02.Data;
using comp2139_project_02.Enum;
using comp2139_project_02.Models;
using comp2139_project_02.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace comp2139_project_02.Controllers
{
    [Authorize(Roles = "admin")]
    public class AdminController : Controller
    {
        private ApplicationDbContext _context;
        private readonly IFileService _fileService;

        public AdminController(ApplicationDbContext context, IFileService fileService)
        {
            _context = context;
            _fileService = fileService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [ActionName("User-Management")]
        public IActionResult UserManagement()
        {
            var users = _context.Users.Where(s => s.Role != "admin").ToList();
                return View(users);
        }

        public IActionResult Items()
        {
            var items = _context.Items.ToList();
            return View(items);
        }

        [HttpGet, ActionName("edit-item")]
        public IActionResult EditItem(int id)
        {
            var item = _context.Items.Find(id);
            ViewBag.Categories = _context.Categories.OrderBy(category => category.CategoryTitle).ToList();
            /*var imgName = _fileService.SaveImage(item.formFile);
            item.itemImage = imgName;*/
            return View(item);
        }

        [HttpPost, ActionName("edit-item")]
        [ValidateAntiForgeryToken]

        public IActionResult EditItem(Item item)
        {
            if (item.FormFile != null)
            {
                var imgName = _fileService.SaveImage(item.FormFile);
                item.ItemImage = imgName;
            }


            if (item.ItemId != 0)
            {
                _context.Items.Update(item);
                _context.SaveChanges();
            }

            return RedirectToAction("view-items", "Seller");
        }

        [HttpGet, ActionName("delete-item")]
        public IActionResult DeleteItem(int id)
        {
            var item = _context.Items.Find(id);
            return View(item);
        }

        [HttpPost, ActionName("delete-item")]
        public IActionResult DeleteItem(Item item)
        {
            _context.Items.Remove(item);
            _context.SaveChanges();
            return RedirectToAction("Items", "Admin");
        }
    }
}

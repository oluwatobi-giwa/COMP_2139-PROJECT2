﻿using comp2139_project_02.Data;
using comp2139_project_02.Enum;
using comp2139_project_02.Models;
using comp2139_project_02.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace comp2139_project_02.Controllers
{
    [Authorize(Roles = "seller")]
    public class SellerController : Controller
    {
        private ApplicationDbContext _context;
        private readonly IFileService _fileService;
        private UserManager<ApplicationUser> _userManager;

        public SellerController(ApplicationDbContext context, IFileService fileService, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _fileService = fileService;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        [ActionName("add-item")]
        public IActionResult AddItem()
        {
            ViewBag.Categories = _context.Categories.OrderBy(category => category.CategoryTitle).ToList();
            return View();
        }

        [HttpPost]
        [ActionName("add-item")]
        public IActionResult AddItem(Item item)
        {
            var imgName = _fileService.SaveImage(item.FormFile);
            item.ItemImage = imgName;

            _context.Add(item);
            _context.SaveChanges();


            return RedirectToAction("Index", "Seller");

            /* return View(item); */

        }

        [ActionName("view-items")]
        public IActionResult ViewItems()
        {
            var user = _userManager.GetUserName(HttpContext.User);

            var items = from s in _context.Items select s;
            var Items = _context.Items.Where(s => s.ItemSeller.Equals(user)).ToList();
            return View(Items);
            
        }
    }
}

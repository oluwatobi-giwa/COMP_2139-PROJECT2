﻿using comp2139_project_02.Data;
using comp2139_project_02.Enum;
using comp2139_project_02.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace comp2139_project_02.Controllers
{
    [Authorize(Roles = "buyer")]
    public class BuyerController : Controller
    {
        private ApplicationDbContext _context;

        public BuyerController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }
        [ActionName("View-Items-Bought")]
        public IActionResult ViewItemsBought()
        {
            return View();
        }

        [ActionName("View-Biddings")]
        public IActionResult ViewBiddings()
        {
            return View();
        }

        [ActionName("Place-Bid")]
        public IActionResult PlaceBid(int id)
        {
            ViewBag.PlaceBid = _context.Items.FirstOrDefault(m => m.ItemId == id);
            return View();
        }

        [HttpPost]
        public IActionResult PlaceBid(Bid bid)
        {
            if (ModelState.IsValid)
            {
                _context.Bids.Add(bid);
                _context.SaveChanges();

                
                return RedirectToAction("Index", "Buyer");
            }
            return RedirectToAction("Index");
        }

        [ActionName("Rate-Seller")]
        public IActionResult RateSeller(string seller)
        {
            
            return View();
        }

        [HttpPost]
        public IActionResult RateSeller(Review review)
        {

            _context.Add(review);
            _context.SaveChanges();

            return RedirectToAction("Index", "Seller");

            /* return View(item); */

        }
    }
}

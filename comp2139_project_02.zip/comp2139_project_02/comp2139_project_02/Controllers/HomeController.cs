﻿using comp2139_project_02.Data;
using comp2139_project_02.Models;
using comp2139_project_02.Models.ViewModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using static Microsoft.Extensions.Logging.EventSource.LoggingEventSource;

namespace comp2139_project_02.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly UserManager<ApplicationUser> _userManager;
        private ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context, UserManager<ApplicationUser> userManager, ILogger<HomeController> logger)
        {
            _logger = logger;
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            ViewBag.TopDeals = _context.Items.OrderBy(r => Guid.NewGuid()).Take(4).ToList();
            ViewBag.Categories = _context.Categories.OrderBy(category => category.CategoryTitle).ToList();
            ViewBag.Trending = _context.Items.OrderBy(r => Guid.NewGuid()).Take(4).ToList();
            return View();
        }

        public IActionResult Sellers()
        {
            var users = _context.Users.Where(s => s.Role == "seller").ToList();
            return View(users);
        }

        public async Task<IActionResult> Seller(string Id)
        {
            var user = await _userManager.FindByNameAsync(Id);

            var sellerVM = new SellerViewModel
            {
                UserName = user.UserName,
                Email = user.Email,
            };
            
            ViewBag.username = user.UserName;
            return View(sellerVM);
        }


        public IActionResult Search(int cat, string keyword) 
        {
            ViewBag.Categories = _context.Categories.OrderBy(category => category.CategoryTitle).ToList();
            var searchResult = _context.Items.ToList();

            if (!string.IsNullOrWhiteSpace(keyword))
            {
                searchResult = searchResult.Where(item => item.ItemName.Contains(keyword, StringComparison.OrdinalIgnoreCase) || item.ItemDesc.Contains(keyword, StringComparison.OrdinalIgnoreCase)).ToList();
            } 
            
            if (cat != 0)
            {
                searchResult = searchResult.Where(item => item.CategoryId == cat).ToList();
            }
            return View(searchResult);
        }

        

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult Issues()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
﻿using comp2139_project_02.Data;
using comp2139_project_02.Enum;
using comp2139_project_02.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;

namespace comp2139_project_02.Controllers
{

    public class CatalogueController : Controller
    {
        private ApplicationDbContext _context;

        public CatalogueController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            ViewBag.Categories = _context.Categories.OrderBy(category => category.CategoryTitle).ToList();

            var countItems = _context.Items.Count();
            ViewBag.Count = countItems;

            var items = _context.Items.ToList();
            return View(items);
        }

        public IActionResult Item(int id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            var item = _context.Items.Include(item => item.Category).FirstOrDefault(item => item.ItemId == id);
            ViewBag.item = item;

            ViewBag.bidItem = _context.Bids.Where(m => m.ItemId == id).Count();

            ViewBag.maxBid = _context.Bids.Where(m => m.ItemId == id).Max(p => p.BidPrice);

            ViewBag.itemsFromSameSeller = _context.Items.Include(i => i.Category).Where(i => i.ItemSeller == item.ItemSeller).Take(4).ToList();


            ViewBag.itemsSameCategory = _context.Items.Include(i => i.Category).Where(i => i.CategoryId == item.CategoryId).Take(4).ToList();
            return View(item);
        }

        [Authorize(Roles = "buyer")]
        [HttpPost]
        public IActionResult Item(Bid bid)
        {
            if (bid.BidPrice < bid.SeedBid)
            {
                ModelState.AddModelError("bid.BidPrice",
                                  "Bid price must be greater than Initial Bid Price.");
            }
            if (ModelState.IsValid)
            {
                _context.Bids.Add(bid);
                _context.SaveChanges();
                return RedirectToAction("Index", "Buyer");
            }
            return RedirectToAction("Index");
        }
    }
}

﻿namespace comp2139_project_02.Enum
{
    public enum Roles
    {
        admin,
        seller,
        buyer
    }
}

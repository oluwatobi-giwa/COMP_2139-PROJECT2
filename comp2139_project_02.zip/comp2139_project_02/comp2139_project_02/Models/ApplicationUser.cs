﻿using Microsoft.AspNetCore.Identity;

namespace comp2139_project_02.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string? Name { get; set; }
        public string? Role { get; set; }
    }
}

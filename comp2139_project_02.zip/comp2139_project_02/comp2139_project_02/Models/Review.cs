﻿using System.ComponentModel.DataAnnotations;

namespace comp2139_project_02.Models
{
    public class Review
    {
        public int ReviewId { get; set; }
        [Required]
        public string? Seller { get; set; }
        [Required]
        public string? Buyer { get; set; }
        [Required]
        [Range(0, 300)]
        public string? Reviews { get; set; }
        [Required]
        public int Ratings { get; set; }
    }
}

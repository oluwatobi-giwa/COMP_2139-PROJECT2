﻿namespace comp2139_project_02.Models
{
    public class Inventory
    {
        public int InventoryId { get; set; }
        
        public double SeedBid { get; set; }
        public int BidNum { get; set; }
        public double HighestBid { get; set; }
        public double HighestBidder { get; set; }
        public string? ItemStatus { get; set; }
    }
}

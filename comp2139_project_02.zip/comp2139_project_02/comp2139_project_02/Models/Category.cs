﻿namespace comp2139_project_02.Models
{
    public class Category
    {
        public int CategoryId { get; set; }
        public string? CategoryTitle { get; set; }
        public string? CategoryIcon { get; set;}
    }
}

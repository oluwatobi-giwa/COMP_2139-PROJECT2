﻿namespace comp2139_project_02.Models.ViewModel
{
    public class SellerViewModel
    {
        public string? UserName { get; set; }
        public string? Email { get; set; }
    }
}

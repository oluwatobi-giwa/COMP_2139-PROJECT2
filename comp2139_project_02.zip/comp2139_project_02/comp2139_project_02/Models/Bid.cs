﻿using System.ComponentModel.DataAnnotations;

namespace comp2139_project_02.Models
{
    public class Bid
    {
        public int BidId { get; set; }
        
        public string? ItemSeller { get; set; }
        public double SeedBid { get; set; }
        public string? ItemBidder { get; set; }
        
        public double? BidPrice { get; set; }
        public string? BidDate { get; set; }
        public string? BidStatus { get; set; }
        public bool IsExpired { get; set; }

        public int ItemId { get; set; }
        public Item? Item { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace comp2139_project_02.Models
{
    public class Item
    {
        public int ItemId { get; set; }
        [Required]
        [Display(Name = "Item Name")]
        public string? ItemName { get; set; }
        [Required]
        [Display(Name = "Item Description")]
        public string? ItemDesc { get; set; }
        [Required]
        [Display(Name = "Minimum Cost")]
        public double MinimumCost { get; set; }
        [Required]
        [Display(Name = "Start Date")]
        public string? StartDate { get; set; }
        [Required]
        [Display(Name = "End Date")]
        public string? EndDate { get; set;}
        [Required]
        [Display(Name = "Item Condition")]
        public string? ItemCondition { get; set; }
        [Required]
        public int CategoryId { get; set; }
        public Category? Category { get; set; }
        /*public string? ItemCategory { get; set; }*/
        
        [Required]
        public string? ItemImage { get; set; }
        [NotMapped]
        public IFormFile? FormFile { get; set; }
        [Required]
        public string? ItemSeller { get; set; }

        public int BidNum { get; set; }
        public double HighestBid { get; set; }
        public string? HighestBidder { get; set; }
        public string? ItemStatus { get; set; }

        public string Slug => ItemName?.Replace(' ', '-').ToLower();
    }
}

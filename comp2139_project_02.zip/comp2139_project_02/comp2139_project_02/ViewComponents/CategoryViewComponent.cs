﻿using comp2139_project_02.Data;
using Microsoft.AspNetCore.Mvc;

namespace comp2139_project_02.ViewComponents
{
    public class CategoryViewComponent : ViewComponent
    {
        private readonly ApplicationDbContext _context;
        public CategoryViewComponent(ApplicationDbContext applicationDbContext)
        {
            _context = applicationDbContext;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            return View("Index", _context.Categories.ToList());
        }
    }
}

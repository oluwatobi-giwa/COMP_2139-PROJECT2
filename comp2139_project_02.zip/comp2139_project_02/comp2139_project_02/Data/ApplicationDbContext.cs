﻿using comp2139_project_02.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace comp2139_project_02.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Bid> Bids { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Review> Reviews { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    CategoryId = 1,
                    CategoryTitle = "Artifacts",
                    CategoryIcon = "fa-solid fa-palette"
                },
                new Category
                {
                    CategoryId = 2,
                    CategoryTitle = "Artillery",
                    CategoryIcon = "fa-solid fa-person-rifle"
                },
                new Category
                {
                    CategoryId = 3,
                    CategoryTitle = "Books",
                    CategoryIcon = "fa-solid fa-book"
                },
                new Category
                {
                    CategoryId = 4,
                    CategoryTitle = "Cars",
                    CategoryIcon = "fa-solid fa-car"
                },
                new Category
                {
                    CategoryId = 5,
                    CategoryTitle = "Furniture",
                    CategoryIcon = "fa-solid fa-couch"
                },
                new Category
                {
                    CategoryId = 6,
                    CategoryTitle = "Jewelries",
                    CategoryIcon = "fa-solid fa-gem"
                }
           );
            /*modelBuilder.Entity<IdentityUserLogin<string>>().HasNoKey();
            modelBuilder.Entity<IdentityUserRole<string>>().HasNoKey();
            modelBuilder.Entity<IdentityUserToken<string>>().HasNoKey();*/

            base.OnModelCreating(modelBuilder);
        }
    }
}
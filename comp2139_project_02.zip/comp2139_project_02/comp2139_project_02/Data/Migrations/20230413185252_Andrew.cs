﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace comp2139_project_02.Data.Migrations
{
    public partial class Andrew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ItemCode",
                table: "Items");

            migrationBuilder.DropColumn(
                name: "ItemCode",
                table: "Inventory");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ItemCode",
                table: "Items",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ItemCode",
                table: "Inventory",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace comp2139_project_02.Data.Migrations
{
    public partial class LateUpdate1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "SeedBid",
                table: "Bids",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SeedBid",
                table: "Bids");
        }
    }
}

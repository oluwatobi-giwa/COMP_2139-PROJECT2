﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace comp2139_project_02.Data.Migrations
{
    public partial class NewlyBid : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "BidPrice",
                table: "Bids",
                type: "float",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BidPrice",
                table: "Bids");
        }
    }
}

﻿using comp2139_project_02.Models;
using Microsoft.AspNetCore.Identity;

namespace comp2139_project_02.Data
{
    public class ContextSeed
    {
        public static async Task SeedRolesAsync(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            await roleManager.CreateAsync(new IdentityRole(Enum.Roles.admin.ToString()));
            await roleManager.CreateAsync(new IdentityRole(Enum.Roles.seller.ToString()));
            await roleManager.CreateAsync(new IdentityRole(Enum.Roles.buyer.ToString()));
        }

        public static async Task SeedSuperAdminAsync(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            var defaultUser = new ApplicationUser
            {
                UserName = "Admin",
                Email = "admin@gmail.com",
                Name = "Super Admin",
                Role = "admin",
                EmailConfirmed = true,
                PhoneNumberConfirmed = true
            };

            if (userManager.Users.All(u => u.Id != defaultUser.Id))
            {
                var user = await userManager.FindByEmailAsync(defaultUser.Email);
                await userManager.CreateAsync(defaultUser, "123Password1$");
                await userManager.AddToRoleAsync(defaultUser, Enum.Roles.admin.ToString());
                
                if (user == null)
                {

                    /*await userManager.AddToRoleAsync(defaultUser, Enum.Roles.Seller.ToString());*/
                }

            }
        }
    }
}

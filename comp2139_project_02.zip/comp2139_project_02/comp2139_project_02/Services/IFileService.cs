﻿namespace comp2139_project_02.Services
{
    public interface IFileService
    {
        string SaveImage(IFormFile formFile);
        bool DeleteImage(string imageFileName);
    }
}

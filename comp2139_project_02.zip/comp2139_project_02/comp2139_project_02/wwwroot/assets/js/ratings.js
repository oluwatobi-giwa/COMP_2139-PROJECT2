'use strict';

(function($){
 

$('.wrap-rating').each(function(){
        var item = $(this).find('.item-rating');
        var rated = -1;
        var input = $(this).find('input');
        $(input).val(0);

        $(item).on('mouseenter', function(){
            var index = item.index(this);
            var i = 0;
            for(i=0; i<=index; i++) {
                $(item[i]).removeClass('fa-regular');
                $(item[i]).addClass('fa-solid');
            }

            for(var j=i; j<item.length; j++) {
                $(item[j]).addClass('fa-regular');
                $(item[j]).removeClass('fa-solid');
            }
        });

        $(item).on('click', function(){
            var index = item.index(this);
            rated = index;
            $(input).val(index+1);
        });

        $(this).on('mouseleave', function(){
            var i = 0;
            for(i=0; i<=rated; i++) {
                $(item[i]).removeClass('fa-regular');
                $(item[i]).addClass('fa-solid');
            }

            for(var j=i; j<item.length; j++) {
                $(item[j]).addClass('fa-regular');
                $(item[j]).removeClass('fa-solid');
            }
        });
    });
	

})(jQuery);